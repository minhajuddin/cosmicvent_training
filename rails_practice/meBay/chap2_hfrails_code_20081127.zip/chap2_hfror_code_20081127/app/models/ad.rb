class Ad < ActiveRecord::Base
end
